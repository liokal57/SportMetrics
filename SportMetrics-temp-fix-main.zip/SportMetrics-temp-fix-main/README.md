\# 🏀 SportMetrics API



API interne de démonstration (FastAPI) pour les données fictives de l'équipe FFS.



\## 🚀 Installation



1\. Cloner ou copier le dossier `SportMetrics` sur votre ordinateur.



2\. Ouvrir un terminal dans le dossier `SportMetrics`.



3\. Créer un environnement virtuel :

&nbsp;  ```bash

&nbsp;  python -m venv .venv

